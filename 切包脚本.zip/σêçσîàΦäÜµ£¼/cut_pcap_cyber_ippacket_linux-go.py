#!/usr/bin/env python
#coding=utf-8
import sys
import struct
import os
import shutil
import csv


def write_pcap(pcap_header_string, tuple_info, tup_name_dict,file_name, pcap_dir):#写文件内容（文件名，pcap地址）
	num = 0
	namezo = []
	file_name = file_name + '_ip正向'#新建一个文件名+_ip的文件夹
	if os.path.exists(os.path.join(pcap_dir, file_name)):#如果有这个文件夹就删除
		shutil.rmtree(os.path.join(pcap_dir ,file_name))
	os.mkdir(os.path.join(pcap_dir , file_name))#新建一个
		
	for key in tuple_info:
			
			if tup_name_dict.has_key(key):
				name = tup_name_dict[key]
				if name not in namezo:
					namezo.append(name)
				else:
					name = key + name
					namezo.append(name)
				tup_name_dict[key] = name
				finap = open(os.path.join(pcap_dir , file_name , tup_name_dict[key]),'wb')
				finap.write(pcap_header_string + tuple_info[key])
				finap.close()
			else:
				continue
			num += 1
		 
def read_pcap(filedir, pcap_dir):
	i =24
	tuple_info = {}#建立字典
	split_info = {}
	last_len_info = {}
	packet_num = 0
	fpcap = open(filedir,'rb')
	string_data = fpcap.read()#报文能读


	file_middle_name = filedir.split("\\")[-1]
	file_name = file_middle_name.split(".")[0]
	pcap_header_string = string_data[0:24]
	if pcap_header_string[0:4] == '\xD4\xC3\xB2\xA1':
		little_endian = 1
	else:
		little_endian = 0
	tup_name_dict = {}
	
	with open('tuple.csv') as f:
		reader = csv.reader(f)
		for row in reader:
			if row[0].find('Test Type') != -1:
				continue
#			if row[2] == '0':
			temp_tuple =  row[8]+  "-" +row[9]
			temp_tuple_contrary = row[9]+  "-" +row[8]
			if tup_name_dict.has_key(temp_tuple_contrary):
				temp_tuple = temp_tuple_contrary
			if tup_name_dict.has_key(temp_tuple):
				continue
			else:

				tempname = row[3]+'.pcap'
				flag1 = tempname.find("/")
				flag2 = tempname.find(":")	
				flag3 = tempname.find("<")
				flag4 = tempname.find("+")
				if (flag1 != -1):
					tempname = tempname.replace("/","")
					#print tempname
				if(flag2 != -1):
					tempname = tempname.replace(":","")
					#print tempname	
				if(flag3 != -1):
					tempname = tempname.replace("<","")
					#print tempname	
				if(flag4 != -1):
					tempname = tempname.replace("+","")
					#print tempname	
				

				tup_name_dict[temp_tuple] = tempname

				#if (flag3 == -1):
					#continue
				#else:
					#tempname = tempname.replace("::","-")
					#print tempname
				#if (flag4 == -1):
					#continue
				#else:
					#tempname = tempname.replace("<","-")
					#print tempname

		#for key in tup_name_dict:
			#print(key,'value',tup_name_dict[key])#有251-250
			
	while(i < len(string_data)):
		pcap_packet_header = string_data[i:i+16]

		pcap_packet_header_len = string_data[i+12:i+16]
		if little_endian:
			packet_len = struct.unpack('I',pcap_packet_header_len)[0]
		else:
			packet_len = struct.unpack('>I',pcap_packet_header_len)[0]
		packet_value = string_data[i+16:i+16+packet_len]
		i = i+ packet_len+16
		
		if packet_value[12:14] == '\x08\x06' :#or packet_value[23] == '\x06' or packet_value[23] == '\x11':
			continue
		
		sip = packet_value[26:30]
		sip_str = str(ord(sip[0])) + "." + str(ord(sip[1])) + "." + str(ord(sip[2])) + "." + str(ord(sip[3]))
		dip = packet_value[30:34]
		dip_str = str(ord(dip[0])) + "." + str(ord(dip[1])) + "." + str(ord(dip[2])) + "." + str(ord(dip[3]))

		tuple_string = sip_str +  "-" + dip_str 
		tuple_contrary_string = dip_str + "-" + sip_str 

		if tuple_info.has_key(tuple_string):
			tuple_info[tuple_string] += pcap_packet_header + packet_value
			element = tuple_string
		elif tuple_info.has_key(tuple_contrary_string):
			tuple_info[tuple_contrary_string] += pcap_packet_header + packet_value	
			element = tuple_contrary_string
			
		else:
			tuple_info[tuple_string] = pcap_packet_header + packet_value
			element = tuple_string
		last_len_info[element] = len(pcap_packet_header + packet_value)
		
		# if  (packet_value[23] == '\x11' or 				\
			 # packet_value[23] == '\x06') and			\
			 # (struct.unpack('!H2',packet_value[46:48])[0])&0xff == 0x02:
			# if split_info.has_key(element):
				# split_info[element].append(len(tuple_info[element])- last_len_'info[element])
			# else:
				# split_info[element] = []
	
	#for key in tuple_info:
			#print(key,'value',tuple_info[key])#有251-250
	
	write_pcap(pcap_header_string, tuple_info, tup_name_dict, file_name,pcap_dir)		

def is_contain_file(pcap_path):
	flag = 0
	for item in pcap_path:
		if item.endswith(".pcap"):#遍历文件夹中的文件，确定是否有文件的结尾为.pcap，如果是的话返回flag=1
			flag = 1
			break
	return flag 



def main():#主函数
	try:
		pcap_dir = sys.argv[1] #读pcap文件所在位置的目录，目录是输入的参数
	except:
		print "Error! please input a parameter of the pcap directory!"
		pcap_dir = '.'
#		sys.exit(1)

	if os.path.isdir(pcap_dir):
		files = os.listdir(pcap_dir)
		if is_contain_file(files) == 1:
			for item in files:
				if item.endswith(".pcap"):
					read_pcap(os.path.join(pcap_dir , item), pcap_dir)#如果是pcap结尾的文件，读取
		else:
			print "Error! the directory does not contain any pcap file!"
			exit(1)
	elif pcap_dir.endswith(".pcap"):#如果输入的是以pcap结尾的目录参数
				if os.path.exists(pcap_dir):
						read_pcap(pcap_dir, "\\".join(pcap_dir.split("\\")[:-1]))
				else:
						print "Error! the pcap is not exit please check it!"
						exit(1)
	else:
		print "Error! the directory is not true please check it!"
		sys.exit(1)


if __name__ == '__main__':
	main()
